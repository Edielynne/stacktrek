function hero(bullets, dragons) {
   let d_bullet = bullets/2

   if (d_bullet >= dragons) {return true}

    else  {return false}


  }
  console.log("hello")